# Arduino CLI plugin

This plugin adds completion for the [arduino-cli](https://github.com/arduino/arduino-cli) tool.

To use it, add `arduino-cli` to the plugins array in your zshrc file:

```zsh
plugins=(... arduino-cli)
```
